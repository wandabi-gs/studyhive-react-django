/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx,ts,tsx}'],
  theme: {
    extend: {
      colors: {
        main: '#F1F7EE',
        primary: '#5E2BFF',
        secondary: '#212227',
        basic: '#1B998B',
        extra:"#A44200"
      }
    },
  },
  plugins: [],
}



// colors: {
//   primary: '#0C356A',
//   secondary: '#279EFF',
//   basic: '#40F8FF',
//   success: '#D5FFD0',
// },