export type recommendationModel = {
    id?:number,
    uid? :string,
    title? :string,
    url? :string,
    preview? :string,
}

export type intrestModel = {
    id?:number,
    uid? :string,
    name? :string,
    description? :string
    recommendations ? : recommendationModel[]
}

export type categoryModel = {
    id?:number,
    uid? :string,
    name? :string,
    description? :string
    intrests :intrestModel[]
}

export type userInterestModel = {
    interests? : intrestModel[]
}