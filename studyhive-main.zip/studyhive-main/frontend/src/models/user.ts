type userModel = {
    email: string;
    password: string;
    username?: string; 
};

const defaultUserModel : userModel = {
    email : "",
    password : "",
    username : "",
}