import { lazy, Suspense, useEffect } from 'react'
import { Routes, Route} from 'react-router-dom'
import Navbar from './components/Navbar'
import { is_authenticated } from './backend'
import useAuthStore from './store/auth'

function App() {

  const Home = lazy(() => import("./components/Home"))
  const Login = lazy(() => import("./components/auth/Login"))
  const Register = lazy(() => import("./components/auth/Register"))
  const Logout = lazy(() => import('./components/auth/Logout'));
  const Categories = lazy(() => import('./components/interest/Categories'))

  const login = useAuthStore((state) => state.login)

  useEffect(() => {
    if(is_authenticated()){
      login()
    }
  })

  return (
    <Suspense fallback="Loading ....." >
    <Navbar />
      <Routes>
        <Route path='' element={<Home />} />
        <Route path='/login' element={<Login />} />
        <Route path='/register' element={<Register />} />
        <Route path='/logout' element={<Logout />} />
        <Route path='/interests' element={<Categories />} />
      </Routes>
    </Suspense>
  )
}

export default App