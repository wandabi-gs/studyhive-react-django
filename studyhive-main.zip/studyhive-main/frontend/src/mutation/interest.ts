import { executeMutation } from "../backend";

export const UserLogin = async (data: userModel) => {
  const { email, password } = data;

  const mutation = `
    mutation($email: String!, $password: String!) {
      loginUser(email: $email, password: $password) {
        token
      }
    }
  `;

  const variables = { email, password }; // Define variables

  const response : any = await executeMutation(mutation, variables);

  return response.loginUser.token;
};


export const addUserIntrestMutation =async (uid: string) => {
    const mutation = `
        mutation($uid:String){
            
        }
    `;
}