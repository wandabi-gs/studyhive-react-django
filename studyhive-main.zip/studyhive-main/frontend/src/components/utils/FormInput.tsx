import { ChangeEventHandler } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';

type FormInputType = {
    className? : string
    name : string
    value : string
    type : string
    onChange : ChangeEventHandler<HTMLInputElement>
    icon? : any
    icon2? : any
    iconClick? : any
    autoFocus? : boolean
}

export const FormInput = ({ className , name, value, type, onChange, icon, icon2, iconClick, autoFocus } : FormInputType) => {
    const capitalizeFirstLetter = (str : string) => {
        return str.split(' ').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ');
    };

    const formattedName = capitalizeFirstLetter(name);

    return (
        <div className={`${className} mt-5`}>
            <label htmlFor="email" className="block font-bold">
                {formattedName}
            </label>
            <div className="flex relative mt-2">
                <input
                    autoFocus={autoFocus}
                    type={type}
                    value={value}
                    onChange={onChange}
                    placeholder=''
                    autoComplete='off'
                    className={`w-full ${icon && "pl-8"} ${icon2 && "pr-8"} border border-indigo-500 focus:border-indigo-500 placeholder-shown:border-gray-300 p-2 rounded-md outline-none peer bg-transparent`}
                />
                {icon &&
                    <FontAwesomeIcon
                        icon={icon}
                        className="self-center peer-placeholder-shown:text-gray-300 peer-focus:text-indigo-700 text-indigo-700 ml-2 absolute"
                    />
                }
                {icon2 &&
                    <FontAwesomeIcon
                        icon={icon2}
                        onClick={iconClick}
                        className="self-center peer-placeholder-shown:text-gray-300 peer-focus:text-indigo-700 text-indigo-700 right-0 mr-2 absolute"
                    />
                }
            </div>
        </div>
    );
};
