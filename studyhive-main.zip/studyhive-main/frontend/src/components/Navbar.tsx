import { Link } from 'react-router-dom'
import useAuthStore from '../store/auth';
import { useEffect } from 'react';

function Navbar() {
    const routes = [
        {
            route: "/",
            name: "Home",
            auth: "all"
        },
        {
            route: "/interests",
            name: "Intrests",
            auth: "all"
        },
        {
            route: "/account",
            name: "Account",
            auth: "auth"
        },
        {
            route: "/login",
            name: "Login",
            auth: "not"
        },
        {
            route: "/register",
            name: "Register",
            auth: "not"
        },
        {
            route: "/logout",
            name: "Logout",
            auth: "auth"
        }
    ]

    const is_authenticated = useAuthStore((state) => state.isAuthenticated);

    useEffect(() => {

    },[is_authenticated])

    return (
        <nav className="h-16 bg-white text-gray-800 text-xl px-3 mb-3 flex justify-center">
            {routes.map((route, index) => {
                if (route.auth === "all") {
                    return (
                        <Link key={index} to={route.route} className='h-full flex flex-col justify-center mx-3 hover:text-indigo-700'>{route.name}</Link>
                    )
                } else if (route.auth === "auth" && is_authenticated) {
                    return (
                        <Link key={index} to={route.route} className='h-full flex flex-col justify-center mx-3 hover:text-indigo-700'>{route.name}</Link>
                    )
                } else if (route.auth === "not" && !is_authenticated) {
                    return (
                        <Link key={index} to={route.route} className='h-full flex flex-col justify-center mx-3 hover:text-indigo-700'>{route.name}</Link>
                    )
                }
            })}
        </nav>
    )
}

export default Navbar