import { useQuery } from "react-query"
import { categoriesQuery } from "../../query/interest"
import { useState } from "react"
import { categoryModel } from "../../models/intrest"

function Categories() {

  const [categories, setCategories] = useState([])

  const { isLoading } = useQuery('products', categoriesQuery, {
    onSuccess: (data) => {
      setCategories(data)
    }
  })

  if (isLoading) return (<div>Loading...</div>)

  return (
    <div>
      {categories.map((category: categoryModel, index) => (
        <div className="m-4 bg-white shadow p-3" key={index}>
          <h3 className="text-2xl">{category.name}</h3>
          <div className="flex space-x-4 mt-2">
            {category.intrests.map((interest, cindex) => (
              <div className="basis-3/12 border p-4" key={cindex}>
                <p className="text-xl">{interest.name}</p>
                <hr />
                <div className="h-full flex flex-col">
                  <p className="my-3">{interest.description}</p>
                  <hr />
                  <div className="mt-3 flex justify-end">
                    <button type="button" className="px-4 py-2 hover:bg-indigo-500 bg-indigo-600 text-white">Add</button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  )
}

export default Categories