import { faUser, faLock, faEyeSlash, faEye } from "@fortawesome/free-solid-svg-icons";
import { useState, FormEvent } from "react";
import { useMutation } from "react-query";
import { useNavigate, Link } from "react-router-dom";
import Cookies from "ts-cookies";
import { UserLogin } from "../../mutation/user";
import { FormInput } from "../utils/FormInput";
import AuthBase from "./Auth";
import useAuthStore from "../../store/auth";

const Login = () => {
    const navigate = useNavigate();

    const login = useAuthStore((state) => state.login);

    const [input, setInput] = useState({
        email: "",
        password: ""
    })
    const { email, password } = input;
    const update_input = (name: string) => (event: React.ChangeEvent<HTMLInputElement>) => {
        setInput({ ...input, [name]: event.target.value })
    }

    const [passwordVisible, setPasswordVisible] = useState(false)
    const toggle_password = (_event: any) => {
        setPasswordVisible(!passwordVisible)
    }
    const { mutate, isLoading } = useMutation(UserLogin, {
        onSuccess: (data) => {
            Cookies.set("session_token", data)
            login()
            navigate('/')
        },onError: (error) => {
            setIsError(true)
        }
    });

    const handleSubmit = (e: FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        mutate({ "password": password, "email": email });
    }

    const [isError, setIsError] = useState(false)

    return (
        <AuthBase activeRoute="login">
            <div className="my-2 text-start text-red-400">
                {isError && "Please enter valid credentials"}
            </div>
            <form onSubmit={handleSubmit} autoComplete='off'>
                <FormInput autoFocus={true} className="mb-4" icon={faUser} name="email" onChange={update_input('email')} type="email" value={email} />
                <FormInput
                    className="mb-4"
                    icon={faLock}
                    icon2={passwordVisible ? faEyeSlash : faEye}
                    iconClick={toggle_password}
                    name="password"
                    onChange={update_input('password')}
                    type={passwordVisible ? "text" : "password"}
                    value={password}
                />
                <div className="flex justify-between">
                    <Link className='py-2 text-indigo-700 hover:text-indigo-500' to="/" >Forgot password?</Link>
                    <button disabled={isLoading ? true : false} className="block bg-indigo-500 hover:bg-indigo-600 active:bg-indigo-700 focus:bg-indigo-700 text-white font-bold py-2 px-4 rounded">
                        {isLoading ? "Logging in ...." : "Login"}
                    </button>
                </div>
            </form>
        </AuthBase>
    )
}

export default Login;