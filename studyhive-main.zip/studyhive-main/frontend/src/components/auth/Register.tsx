import { faEnvelope, faUser, faLock, faEyeSlash, faEye } from "@fortawesome/free-solid-svg-icons";
import { useState, FormEvent } from "react";
import { useMutation } from "react-query";
import { useNavigate, Link } from "react-router-dom";
import { UserRegister } from "../../mutation/user";
import { FormInput } from "../utils/FormInput";
import AuthBase from "./Auth";

const Register = () => {
    const navigate = useNavigate();

    const [input, setInput] = useState({
        email: "",
        username: "",
        password: ""
    })
    const { email, username, password } = input;
    const update_input = (name: string) => (event: React.ChangeEvent<HTMLInputElement>) => {
        setInput({ ...input, [name]: event.target.value })
    }

    const [passwordVisible, setPasswordVisible] = useState(false)
    const toggle_password = (_event: any) => {
        setPasswordVisible(!passwordVisible)
    }

    const { mutate, data: TokenData } = useMutation(UserRegister);

    const handleSubmit = (e: FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        mutate({ "password": password, "email": email, "username": username });
    }
    if (TokenData) {
        navigate("/login")
    }

    return (
        <AuthBase activeRoute="register">
            <form onSubmit={handleSubmit} autoComplete='off'>
                <FormInput autoFocus={true} className="mb-4" icon={faEnvelope} name="email" onChange={update_input('email')} type="email" value={email} />
                <FormInput className="mb-4" icon={faUser} name="full name" onChange={update_input('username')} type="text" value={username} />
                <FormInput
                    className="mb-4"
                    icon={faLock}
                    icon2={passwordVisible ? faEyeSlash : faEye}
                    iconClick={toggle_password}
                    name="password"
                    onChange={update_input('password')}
                    type={passwordVisible ? "text" : "password"}
                    value={password}
                />
                <div className="flex justify-between">
                    <Link className='py-2 text-indigo-700 hover:text-indigo-500' to="">Forgot password?</Link>
                    <button className="block bg-indigo-500 hover:bg-indigo-600 active:bg-indigo-700 focus:bg-indigo-700 text-white font-bold py-2 px-4 rounded">
                        Login
                    </button>
                </div>
            </form>
        </AuthBase>
    )
}

export default Register