import React, { useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { is_authenticated } from '../../backend';

type AuthBaseType = {
    activeRoute : string
    children : React.ReactNode
}

function AuthBase({activeRoute, children} : AuthBaseType) {

    const navigate = useNavigate()

    useEffect(()=>{
        if(is_authenticated()){
            navigate("/")
        }
    },[])

    return (
        <div className="h-screen flex flex-col justify-center">
            <div className='flex justify-center'>
                <div className="bg-white p-6 rounded-lg shadow-md basis-1/4">
                    <div className="py-2 flex justify-center">
                        <Link to='/login'>
                            <h1 className={`${activeRoute === "login" && "text-indigo-600"} text-3xl font-bold text-center`}>Login</h1>
                        </Link>
                        <h1 className="text-3xl font-extralight text-center mx-3">|</h1>
                        <Link to='/register'>
                            <h1 className={`${activeRoute === "register" && "text-indigo-600"} text-3xl font-bold text-center`}>Register</h1>
                        </Link>
                    </div>
                    {children}
                </div>
            </div>
        </div>
    );
}

export default AuthBase;