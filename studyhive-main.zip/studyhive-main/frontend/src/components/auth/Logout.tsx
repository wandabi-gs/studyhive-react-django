import { useEffect } from "react"
import { useNavigate } from "react-router-dom"
import Cookies from "ts-cookies"
import useAuthStore from "../../store/auth"

 const Logout = () => {
    const navigate = useNavigate()
    const logout = useAuthStore((state) => state.logout);

    useEffect(() => {
        Cookies.remove("session_token")
        logout()
        navigate("/")
    },[])
    return(
        <div>Logging Out ........</div>
    )
}

export default Logout