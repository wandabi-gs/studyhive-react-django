import { useState } from "react"
import { useQuery } from "react-query"
import { myInterestQuery } from "../query/interest"
import { intrestModel } from "../models/intrest"
import { Link } from "react-router-dom"

function Home() {

  const [interests, setInterests] = useState([])

  const { isLoading } = useQuery("my-interests", myInterestQuery, {
    onSuccess: (data) => {
      setInterests(data.interests)
    }
  })

  if (isLoading) {
    return (<div>Loading ....</div>)
  }

  console.log(interests)

  return (
    <div>
      {interests.map((interest: intrestModel, index) => (
        <div className="m-4 bg-white shadow p-3" key={index}>
          <h3 className="text-2xl">{interest.name}</h3>
          <div className="my-3 flex flex-nowrap overflow-x-auto w-full">
            {interest.recommendations?.map((recommendation, rindex) => (
              <div key={rindex} className="flex-grow mx-2 border p-3" style={{ minWidth: "25vw" }}>
                <p className="text-xl">{recommendation.title}</p>
                <hr />
                <div className="mt-3">
                  <p>{recommendation.preview}</p>
                  <div className="mt-4">
                    <Link className="text-indigo-700" target="_blank" to={recommendation.url}>{recommendation.url}</Link>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      ))}
    </div>
  )
}

export default Home